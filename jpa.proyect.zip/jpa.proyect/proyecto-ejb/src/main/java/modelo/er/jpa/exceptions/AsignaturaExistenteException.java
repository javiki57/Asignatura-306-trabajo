package modelo.er.jpa.exceptions;

public class AsignaturaExistenteException extends Exception{
	
	public AsignaturaExistenteException() {
		super();
	}
	
	public AsignaturaExistenteException(String msg) {
		super(msg);
	}

}
