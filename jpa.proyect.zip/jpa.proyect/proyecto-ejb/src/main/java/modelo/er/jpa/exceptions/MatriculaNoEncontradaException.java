package modelo.er.jpa.exceptions;

public class MatriculaNoEncontradaException extends Exception{
	
	public MatriculaNoEncontradaException() {
		super();
	}
	
	public MatriculaNoEncontradaException(String msg) {
		super(msg);
	}

}
