package modelo.er.jpa.exceptions;

public class TitulacionNoEncontradaException extends Exception {

	public TitulacionNoEncontradaException() {
		super();
	}
	
	public TitulacionNoEncontradaException(String e) {
		super(e);
	}
}
