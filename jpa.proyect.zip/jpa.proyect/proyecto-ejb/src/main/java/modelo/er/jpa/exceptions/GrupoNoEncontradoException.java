package modelo.er.jpa.exceptions;

public class GrupoNoEncontradoException extends Exception {
	
		public GrupoNoEncontradoException() {
			super();
			
		}
		
		public GrupoNoEncontradoException(String msg) {
			super(msg);
			
		}

}
