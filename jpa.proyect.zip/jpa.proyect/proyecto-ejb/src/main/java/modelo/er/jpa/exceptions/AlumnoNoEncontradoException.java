package modelo.er.jpa.exceptions;

public class AlumnoNoEncontradoException extends Exception{
	
	public AlumnoNoEncontradoException() {
		super();
	}
	
	public AlumnoNoEncontradoException(String msg) {
		super(msg);
	}

}
