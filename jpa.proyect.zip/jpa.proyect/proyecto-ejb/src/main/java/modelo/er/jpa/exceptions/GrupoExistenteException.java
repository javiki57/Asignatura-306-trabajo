package modelo.er.jpa.exceptions;

public class GrupoExistenteException extends Exception{
	
	public GrupoExistenteException() {
		super();
	}
	
	public GrupoExistenteException(String msg) {
		super(msg);
	}
}
