package modelo.er.jpa.exceptions;

public class AsignaturaNoEncontradaException extends Exception{

	public AsignaturaNoEncontradaException() {
		super();
	}
	
	public AsignaturaNoEncontradaException(String msg) {
		super(msg);
	}
}
