package modelo.er.jpa.exceptions;

public class MatriculaException extends Exception{
	
	
	public MatriculaException () {
		super();
		
	}
	public MatriculaException (String msg) {
		super(msg);
	}

}
