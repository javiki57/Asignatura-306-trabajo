package es.uma.informatica.project;

public @interface Requisitos {

	String[] value();

}
