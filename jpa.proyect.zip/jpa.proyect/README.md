# Instrucciones para la compilación

```
 sudo docker build --tag=mimysql
 sudo docker image ls
 sudo docker run -d --name=(ID DE LA IMAGEN) -p 3306:3306  mimysql (arrancar la imagen)
 sudo docker inspect (nombre de la etiqueta)
``` 
